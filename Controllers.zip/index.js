const mongoose = require("mongoose");
require("dotenv").config();

const uri = process.env.URI;

mongoose.set("strictQuery", true);

async function connectDB() {
  try {
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 30000,
      socketTimeoutMS: 45000,
      connectTimeoutMS: 30000,
    });

    console.log("✅ MongoDB Connected");
  } catch (err) {
    console.log("❌ MongoDB Connection Failed");
    console.log(err);
  }
}

connectDB();